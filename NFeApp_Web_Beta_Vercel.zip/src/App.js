import React from 'react';

function App() {
  return (
    <div style={{ fontFamily: 'sans-serif', padding: '2rem' }}>
      <h1>Bem-vindo ao NFe App Beta</h1>
      <p>Versão Web de teste</p>
      <p>Em breve: upload de certificado digital, consulta automática e organização de NF-e</p>
    </div>
  );
}

export default App;
